# Sentiment Analysis of Social Media Posts Using Transformer-Based Language Models

**Course:** Natural Language Processing · **Program:** Master of Computer Engineering

A complete NLP pipeline that collects real mobile-phone reviews from the web,
preprocesses them, and compares **traditional machine-learning baselines** (TF-IDF +
Naive Bayes / Logistic Regression / SVM / Random Forest) against a **fine-tuned BERT**
transformer classifier for **3-class sentiment analysis** (Negative / Neutral / Positive).

---

## Overview

### What is NLP?
Natural Language Processing (NLP) enables computers to understand, interpret, and
generate human language through computational techniques. It is fundamental to building
intelligent systems that can interact naturally with humans and process massive
amounts of textual data.

### Key Applications
- Chatbots
- Search Engines
- Social Media Monitoring
- Machine Translation
- Text Analytics

---

## Context

### Problem Statement
Organizations need to understand public opinion from large volumes of online text
across multiple platforms.

| Platform / Source | Nature of Text |
|-------------------|----------------|
| Twitter / X       | Real-time public discourse |
| Facebook          | Community conversations |
| Product Reviews   | Consumer sentiment |
| News Comments     | Public opinion on events |

### Key Challenges
- Large volume of text
- Informal language & slang
- Abbreviations
- Mixed sentiments

---

## Project Objectives

1. **Collect Textual Data** – Gather reviews from relevant platforms (GSMArena).
2. **Preprocess Text** – Clean and normalize raw text for model consumption.
3. **Build Classification Models** – Develop sentiment classifiers using ML **and**
   Language Models.
4. **Compare Approaches** – Evaluate traditional ML against Transformer-based LMs.
5. **Evaluate Performance** – Measure accuracy, precision, recall, and F1.

---

## Data

### Dataset Information

Data is collected from **GSMArena** (mobile phone reviews) via the scraper
`collectReviwes.py`.

| Attribute | Value |
|-----------|-------|
| Number of Records (raw reviews) | 4,071 |
| Number of Records (labeled, after cleaning) | 4,033 |
| Unique Products (phones) | 1,521 |
| Positive Samples | 2,087 (51.8%) |
| Neutral Samples | 1,004 (24.9%) |
| Negative Samples | 942 (23.3%) |
| Source | GSMArena (https://www.gsmarena.com/reviews.php3) |

Labels are generated automatically with **VADER** (Valence Aware Dictionary and
sEntiment Reasoner), a lexicon-based sentiment analyser tuned for social-media text.

### Generated Data Files

| File | Description |
|------|-------------|
| `customer_reviews.json` | Raw scraped reviews (phone → list of review texts) |
| `cleaned_reviews.csv` | Lowercased, emoji-/punctuation-removed text |
| `preprocessed_reviews.csv` | + stop-word removal and lemmatisation (token lists) |
| `labeled_data.csv` | Final dataset: `phone, text, preprocessed_text, sentiment(0/1/2), sentiment_name, compound` |

> `customer_reviews.json` is the only tracked data file (the rest are regenerable).

---

## Methodology — NLP Pipeline

```
Data Collection → Cleaning → Tokenization → Feature Extraction → Model Training → Evaluation
```

### Step 1 – Data Preprocessing (`preprocessor.py`)
- Lowercasing
- Remove punctuation / non-alpha characters
- Remove URLs (handled via BeautifulSoup text extraction)
- Remove emojis (`emoji` library)
- Remove stop words (NLTK English stop-word list)
- Stemming & Lemmatization (NLTK `WordNetLemmatizer`)

### Step 2 – Tokenization
- Word tokenization (NLTK `word_tokenize`)
- Sub-word tokenization (BERT `bert-base-uncased` tokenizer – WordPiece)

### Step 3 – Text Representation

| Method | Type | Context Aware |
|--------|------|---------------|
| Bag of Words (BoW) | Frequency-based | No |
| TF-IDF | Weighted importance | No |
| Word2Vec / GloVe | Dense embeddings | Partial |
| **BERT** | Contextual embeddings | **Yes** |

---

## Background – Language Models

Evolution: `N-grams` → `Word2Vec` → `GloVe` → `LSTM` → `Transformer` → `BERT / GPT`

Language models understand context within sentences, achieve significantly better
accuracy, and capture deep semantic meaning.

---

## Architecture – Transformer

- **Self-Attention** – every token attends to all other tokens to capture dependencies.
- **Positional Encoding** – injects sequence-order information (Transformers have no
  recurrence/convolution).
- **Multi-Head Attention** – parallel attention operations capturing diverse patterns.
- **Feed-Forward Network** – non-linear transformation over attention outputs.

---

## Models

### Baseline Models (TF-IDF Features)
Classical ML classifiers trained on TF-IDF feature vectors (word + 2-gram,
`max_features=20,000`, `sublinear_tf`).

| Model | Description |
|-------|-------------|
| Naïve Bayes | Probabilistic classifier (Bayes' theorem, independence assumption) |
| Logistic Regression | Linear model for binary & multi-class tasks |
| SVM | LinearSVC – optimal decision boundaries in high-dimensional space |
| Random Forest | Ensemble of decision trees (robust, lower variance) |

### Transformer-Based Model – Fine-tuned BERT
`bert.py` fine-tunes the pre-trained `bert-base-uncased` model with a classification
head on the `[CLS]` token output.

| Hyperparameter | Value |
|----------------|-------|
| Model | `bert-base-uncased` |
| Learning Rate | 2e-5 |
| Epochs | 3 |
| Batch Size | 16 |
| Max Sequence Length | 128 |
| Output Classes | 3 (Negative / Neutral / Positive) |

**Sentiment label mapping:** `0 = Negative`, `1 = Neutral`, `2 = Positive`

---

## Experimental Setup

| Split | Proportion | Purpose |
|-------|-----------|---------|
| Training | 80% | Model learning |
| Validation | 10% | Hyperparameter tuning / best checkpoint |
| Testing | 10% | Final evaluation |

`random_state=42`, stratified by sentiment class, so the 10% test set is
**identical** across the traditional baselines and BERT.

### Tools & Libraries
- **Python** – core language
- **Scikit-Learn** – baseline ML models
- **Hugging Face Transformers + PyTorch** – BERT fine-tuning
- **Pandas** – data manipulation
- **NLTK / emoji / BeautifulSoup** – preprocessing & scraping

---

## Evaluation Metrics

- **Accuracy** – overall proportion of correctly classified instances
- **Precision, Recall, F1** – computed per class and as macro/weighted averages
- **Confusion Matrix** – true vs predicted labels per class

---

## Results

### Performance Summary (consistent 80/10/10 stratified split, seed 42, 3-class)

| Model | Accuracy | F1 (macro) | F1 (weighted) |
|-------|:--------:|:----------:|:------------:|
| Naïve Bayes | 54.95% | 31.58% | 42.17% |
| Logistic Regression | 72.03% | 68.82% | 72.19% |
| SVM | 74.01% | 70.51% | 73.72% |
| Random Forest | 71.78% | 64.57% | 69.17% |
| **BERT (fine-tuned)** | **81.68%** | **79.26%** | **81.55%** |

Transformer-based approaches **outperform all traditional baselines**, with BERT
achieving the highest accuracy of **81.68%** — a **+7.7 pp** gain over the strongest
baseline (SVM, 74.01%).

### BERT Test-Set Confusion Matrix (rows = true, order Neg / Neu / Pos)

| | Neg | Neu | Pos |
|---|-----|-----|-----|
| **Predicted Neg** | 67 | 10 | 17 |
| **Predicted Neu** | 10 | 76 | 15 |
| **Predicted Pos** | 15 | 7 | 187 |

BERT is strongest on the **Positive** class (89.5% recall) and weakest on **Neutral**
(75% recall) and **Negative** (71% recall), which are frequently confused with each
other — a common difficulty for 3-class sentiment on short, informal review text
(consistent with the error patterns discussed below).

---

## Analysis – Error Analysis

Even state-of-the-art models struggle with:

- **Sarcasm** – positive words used to express negative intent
  (e.g. *"Great! Another software crash."* → likely misclassified as Positive).
- **Irony** – statements meaning the opposite of their literal interpretation.
- **Domain-Specific Language** – technical jargon and niche terminology not well
  represented in training data.
- **Mixed Sentiments** – text containing both positive and negative opinions
  simultaneously (e.g. *"The camera is amazing but the battery dies in 2 hours."*).

---

## Future Work

| Direction | Potential Models |
|-----------|-----------------|
| Multilingual NLP | mBERT, XLM-R |
| Sinhala-English Mixed (code-switching) text | Indic BERT variants |
| Emotion Detection (joy, anger, fear, …) | EmoBERT, GoEmotions |
| Aspect-Based Sentiment | ABSA-BERT |
| Zero-shot / Few-shot with LLMs | GPT, PaLM via prompting |
| Efficient Transformers | **DistilBERT**, RoBERTa, ALBERT |

---

## Conclusion

- NLP enables machines to automatically understand and process large volumes of
  textual data at scale.
- Transformer-based approaches such as **BERT achieve state-of-the-art results** on
  sentiment tasks, significantly improving classification over traditional ML baselines.
- The project demonstrates the **complete NLP workflow** from raw social-media text to
  intelligent sentiment prediction.

---

## Project Structure

```
.
├── collectReviwes.py              # 1. Scrape GSMArena reviews -> customer_reviews.json
├── preprocessor.py                # 2. Clean, normalise, lemmatise -> cleaned/preprocessed_reviews.csv
├── prepare_data.py                # 3. VADER labelling -> labeled_data.csv (3-class)
├── Traditional_Models_With_TF-IDF.py  # 4. TF-IDF + 4 baselines -> results/traditional_metrics.csv
├── bert.py                        # 5. Fine-tune BERT -> bert_results/ + results/bert_metrics.csv
├── compare_results.py             # 6. Compare all models -> results/comparison_results.csv
├── main.py                        # Orchestrator: runs the whole pipeline end-to-end
├── TF-IDF.py                      # (Legacy) simpler 2-class TF-IDF + Logistic Regression
├── requirements.txt
└── README.md
```

### Generated (not committed)
- `results/` – metric CSVs for traditional models, BERT, and the comparison.
- `bert_results/` – fine-tuned BERT weights, tokenizer, metrics JSON, checkpoints.
- `*_reviews.csv` – intermediate cleaned/preprocessed/labeled data.

---

## How to Run

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. (Optional) download required NLTK data
python -c "import nltk; nltk.download('vader_lexicon'); nltk.download('stopwords'); nltk.download('punkt'); nltk.download('wordnet'); nltk.download('omw-1.4')"

# 3. Run the entire pipeline (collect -> preprocess -> label -> train -> compare)
python main.py

# Or run each stage individually:
python collectReviwes.py                 # scrape reviews (requires network)
python preprocessor.py                   # clean & lemmatise
python prepare_data.py                   # VADER 3-class labelling
python Traditional_Models_With_TF-IDF.py # TF-IDF baselines
python bert.py                           # fine-tune BERT (~1-2h on CPU)
python compare_results.py                # final comparison table
```

### BERT training options
```bash
python bert.py --epochs 3 --batch_size 16 --max_length 128        # default (CPU)
python bert.py --epochs 2 --subset 1000                            # quick smoke test
```

> **Note:** BERT fine-tuning requires downloading `bert-base-uncased` (~440 MB) on
> first use and runs on CPU here (`CUDA` is not available). Adjust `--epochs` /
> `--batch_size` to `0` (auto) or a GPU as needed.

## Reproducibility

- All random splits use `random_state=42` and are **stratified** by the sentiment label,
  so the 20% test set is **identical** across traditional baselines and BERT.
- VADER thresholds: `compound >= 0.05` → Positive, `<= -0.05` → Negative, else Neutral.

---

*Thank you — Questions & Discussion welcome.*
